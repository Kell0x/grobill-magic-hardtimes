/////////////////////////////////////
// Complementary Shaders by EminGT //
/////////////////////////////////////

//Common//
#include "/lib/common.glsl"

//////////Fragment Shader//////////Fragment Shader//////////Fragment Shader//////////
#ifdef FRAGMENT_SHADER

flat in int mat;

in vec2 texCoord;

in vec4 position;
flat in vec4 glColor;

#ifdef CONNECTED_GLASS_EFFECT
    in vec2 signMidCoordPos;
    flat in vec2 absMidCoordPos;
#endif

//Pipeline Constants//
#include "/lib/pipelineSettings.glsl"

//Common Variables//
vec3 upVec = normalize(gbufferModelView[1].xyz);

vec3 sunVec = GetSunVector();

float SdotU = dot(sunVec, upVec);
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) * 8.0;

//Common Functions//
void DoNaturalShadowCalculation(inout vec4 color1, inout vec4 color2) {
    color1.rgb *= glColor.rgb;
    color1.rgb = mix(vec3(1.0), color1.rgb, pow(color1.a, (1.0 - color1.a) * 0.5) * 1.05);
    color1.rgb *= 1.0 - pow(color1.a, 64.0);
    color1.rgb *= 0.1; // 423HDSS: Shadow color strength is stored 10 times lower to allow for water shadows going above 1.0

    color2.rgb = normalize(color1.rgb) * 0.5;
}

//Includes//
#include "/lib/util/dither.glsl"

#ifdef CONNECTED_GLASS_EFFECT
    #include "/lib/materials/materialMethods/connectedGlass.glsl"
#endif

//Program//
void main() {
    vec4 color1 = texture2DLod(tex, texCoord, 0); // Shadow Color
    #ifdef SHADOW_COLORWHEEL
        vec2 lmCoord; // needed as otherwise undeclared in the function below
        float ao;
        vec4 overlayColor;

        clrwl_computeFragment(color1, color1, lmCoord, ao, overlayColor);
    #endif

    #if HIDE_ARMOR > 0
        if (currentRenderedItemId == 45124 && !isElytraFlying) discard;
    #endif

    if (entityId > 0) {
        #if PLAYER_SHADOW == -1
            if (entityId == 50016 || entityId == 50017) { // Player
                discard;
            }
        #endif

        // Entity Shadow Fade Out
        float fadeEnd = shadowDistance * entityShadowDistanceMul + 2.0;
        float fadeStart = fadeEnd * 0.8;
        float opacity = 1.0 - smoothstep(fadeStart, fadeEnd, max(length(position.xz), abs(position.y)));

        float dither = Bayer64(gl_FragCoord.xy);
        if (opacity < dither) discard;
    }

    #if SHADOW_QUALITY >= 1
        vec4 color2 = color1; // Light Shaft Color

        color2.rgb *= 0.25; // Natural Strength

        #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
            float positionYM = position.y;
        #endif

        if (mat < 32008) {
            if (mat < 32000) {
                #if defined CONNECTED_GLASS_EFFECT || defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
                    if (mat == 30008 || mat >= 31000) { // Tinted Glass || Stained Glass, Stained Glass Pane
                        #ifdef CONNECTED_GLASS_EFFECT
                            DoSimpleConnectedGlass(color1);
                        #endif

                        #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
                            positionYM = 0.0; // 86AHGA: For scene-aware light shafts to be less prone to get extreme under large glass planes
                        #endif
                    }
                #endif
                DoNaturalShadowCalculation(color1, color2);
            } else {
                if (mat == 32000) { // Water
                    vec3 worldPos = position.xyz + cameraPosition;

                    #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
                        // For scene-aware light shafts to be more prone to get extreme near water
                        positionYM += 3.5;
                    #endif

                    // Water Caustics
                    #if WATER_CAUSTIC_STYLE < 3
                        #if MC_VERSION >= 11300
                            float wcl = GetLuminance(color1.rgb);
                            color1.rgb = color1.rgb * pow2(wcl) * 1.2;
                        #else
                            color1.rgb = mix(color1.rgb, vec3(GetLuminance(color1.rgb)), 0.88);
                            color1.rgb = pow2(color1.rgb) * vec3(2.5, 3.0, 3.0) * 0.96;
                        #endif
                    #else
                        #define WATER_SPEED_MULT_M WATER_SPEED_MULT * 0.035
                        vec2 causticWind = vec2(0.0, frameTimeCounter * WATER_SPEED_MULT_M);
                        vec2 cPos1 = worldPos.xz * 0.08 + causticWind;
                        vec2 cPos2 = worldPos.xz * 0.06 - causticWind;

                        float cMult = 14.0;
                        float offset = 0.001;

                        float caustic = 0.0;
                        caustic += dot(texture2D(gaux4, cPos1 + vec2(offset, 0.0)).rg, vec2(cMult))
                                 - dot(texture2D(gaux4, cPos1 - vec2(offset, 0.0)).rg, vec2(cMult));
                        caustic += dot(texture2D(gaux4, cPos2 + vec2(0.0, offset)).rg, vec2(cMult))
                                 - dot(texture2D(gaux4, cPos2 - vec2(0.0, offset)).rg, vec2(cMult));
                        color1.rgb = vec3(max0(min1(caustic * 0.8 + 0.35)) * 0.65 + 0.35);

                        #if MC_VERSION < 11300
                            color1.rgb *= vec3(0.3, 0.45, 0.9);
                        #endif
                    #endif

                    #if MC_VERSION >= 11300
                        #if WATERCOLOR_MODE >= 2
                            color1.rgb *= glColor.rgb;
                        #else
                            color1.rgb *= vec3(0.3, 0.45, 0.9);
                        #endif
                    #endif
                    color1.rgb *= vec3(0.6, 0.8, 1.1);
                    color1.rgb = pow(color1.rgb, vec3(0.75)) * 0.5;
                    ////

                    // Underwater Light Shafts
                    vec3 worldPosM = worldPos;

                    #if WATER_FOG_MULT > 100
                        #define WATER_FOG_MULT_M WATER_FOG_MULT * 0.01;
                        worldPosM *= WATER_FOG_MULT_M;
                    #endif

                    vec2 waterWind = vec2(syncedTime * 0.01, 0.0);
                    float waterNoise = texture2DLod(noisetex, worldPosM.xz * 0.012 - waterWind, 0.0).g;
                          waterNoise += texture2DLod(noisetex, worldPosM.xz * 0.05 + waterWind, 0.0).g;

                    float factor = max(2.5 - 0.025 * length(position.xz), 0.8333) * 1.3;
                    waterNoise = pow(waterNoise * 0.5, factor) * factor * 1.3;

                    #if MC_VERSION >= 11300 && WATERCOLOR_MODE >= 2
                        color2.rgb = normalize(sqrt1(glColor.rgb)) * vec3(0.24, 0.22, 0.26);
                    #else
                        color2.rgb = vec3(0.08, 0.12, 0.195);
                    #endif
                    color2.rgb *= waterNoise * (1.0 + sunVisibility - rainFactor);

                    #if LIGHTSHAFT_WATER_I != 100
                        if (isEyeInWater == 0)
                            color2.rgb *= LIGHTSHAFT_WATER_I * 0.01;
                    #endif
                    ////

                    #ifdef UNDERWATERCOLOR_CHANGED
                        color1.rgb *= vec3(UNDERWATERCOLOR_RM, UNDERWATERCOLOR_GM, UNDERWATERCOLOR_BM);
                        color2.rgb *= vec3(UNDERWATERCOLOR_RM, UNDERWATERCOLOR_GM, UNDERWATERCOLOR_BM);
                    #endif
                } else /*if (mat == 32004)*/ { // Ice
                    color1.rgb *= color1.rgb;
                    color1.rgb *= color1.rgb;
                    color1.rgb = mix(vec3(1.0), color1.rgb, pow(color1.a, (1.0 - color1.a) * 0.5) * 1.05);
                    color1.rgb *= 1.0 - pow(color1.a, 64.0);
                    color1.rgb *= 0.14; // 423HDSS

                    color2.rgb = normalize(pow(color1.rgb, vec3(0.25))) * 0.5;
                }
            }
        } else {
            if (mat < 32020) { // Glass, Glass Pane, Beacon (32008, 32012, 32016)
                #ifdef CONNECTED_GLASS_EFFECT
                    if (mat == 32008) { // Glass
                        DoSimpleConnectedGlass(color1);
                    }
                    if (mat == 32012) { // Glass Pane
                        DoSimpleConnectedGlass(color1);
                    }
                #endif
                if (color1.a > 0.5) color1 = vec4(0.0, 0.0, 0.0, 1.0);
                else color1 = vec4(vec3(0.1 * (1.0 - GLASS_OPACITY)), color1.a); // 423HDSS
                color2.rgb = vec3(0.3);

                #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
                    positionYM = 0.0; // 86AHGA
                #endif
            } else {
                DoNaturalShadowCalculation(color1, color2);
            }
        }
    #endif

    #if LIGHTSHAFT_WATER_I != 100
        if (isEyeInWater == 1)
            color2.rgb *= LIGHTSHAFT_WATER_I * 0.01;
    #endif

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = color1; // Shadow Color

    #if SHADOW_QUALITY >= 1
        #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
            color2.a = 0.25 + max0(positionYM * 0.05); // consistencyMEJHRI7DG
        #endif

        /* DRAWBUFFERS:01 */
        gl_FragData[1] = color2; // Light Shaft Color
    #endif
}

#endif

//////////Vertex Shader//////////Vertex Shader//////////Vertex Shader//////////
#ifdef VERTEX_SHADER

flat out int mat;

out vec2 texCoord;

out vec4 position;
flat out vec4 glColor;

#ifdef CONNECTED_GLASS_EFFECT
    out vec2 signMidCoordPos;
    flat out vec2 absMidCoordPos;
#endif

//Pipeline Constants//
#if COLORED_LIGHTING_INTERNAL > 0
    #extension GL_ARB_shader_image_load_store : enable
#endif

//Attributes//
attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;

#if COLORED_LIGHTING_INTERNAL > 0
    attribute vec3 at_midBlock;
#endif

//Common Variables//
vec2 lmCoord;

#if COLORED_LIGHTING_INTERNAL > 0
    layout(r32ui) uniform uimage3D voxel_img;

    #ifdef PUDDLE_VOXELIZATION
        writeonly uniform uimage2D puddle_img;
    #endif

    #if WORLD_SPACE_REFLECTIONS_INTERNAL > 0
        writeonly uniform uimage3D wsr_img;
        writeonly uniform uimage3D wsr_lod_img;
    #endif
#endif

//Common Functions//

//Includes//
#include "/lib/util/spaceConversion.glsl"

#if defined WAVING_ANYTHING_TERRAIN || defined WAVING_WATER_VERTEX
    #include "/lib/materials/materialMethods/wavingBlocks.glsl"
#endif

#if COLORED_LIGHTING_INTERNAL > 0
    #include "/lib/voxelization/lightVoxelization.glsl"

    #ifdef PUDDLE_VOXELIZATION
        #include "/lib/voxelization/puddleVoxelization.glsl"
    #endif

    #if WORLD_SPACE_REFLECTIONS_INTERNAL > 0
        #include "/lib/voxelization/reflectionVoxelization.glsl"
    #endif
#endif

//Program//
void main() {
    texCoord = gl_MultiTexCoord0.xy;
    lmCoord = GetLightMapCoordinates();
    glColor = gl_Color;
    mat = int(mc_Entity.x + 0.5);

    position = shadowModelViewInverse * shadowProjectionInverse * ftransform();

    #if defined WAVING_ANYTHING_TERRAIN || defined WAVING_WATER_VERTEX
        DoWave(position.xyz, mat);
    #endif

    #ifdef CONNECTED_GLASS_EFFECT
        vec2 midCoord = (gl_TextureMatrix[0] * mc_midTexCoord).st;
        vec2 texMinMidCoord = texCoord - midCoord;
        signMidCoordPos = sign(texMinMidCoord);
        absMidCoordPos  = abs(texMinMidCoord);
    #endif

    #ifdef PERPENDICULAR_TWEAKS
        if (mat == 10005 || mat == 10017) { // Foliage
            #ifndef CONNECTED_GLASS_EFFECT
                vec2 midCoord = (gl_TextureMatrix[0] * mc_midTexCoord).st;
                vec2 texMinMidCoord = texCoord - midCoord;
            #endif
            vec3 normal = gl_NormalMatrix * gl_Normal;
            position.xyz += normal * sign(texMinMidCoord.y) * 0.2 * noonFactor * (1.0 + 0.01 * length(position.xyz));
        }
    #endif

    if (mat == 32000) { // Water
        position.y += 0.015 * max0(length(position.xyz) - 50.0); // WS752GH42G
    }

    #if COLORED_LIGHTING_INTERNAL > 0
        if (gl_VertexID % 4 == 0) {
            #ifndef SHADOW_COLORWHEEL
                bool solidTerrain = any(equal(ivec3(renderStage), ivec3(
                    MC_RENDER_STAGE_TERRAIN_SOLID,
                    MC_RENDER_STAGE_TERRAIN_CUTOUT,
                    MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED
                )));
            #else
                bool solidTerrain = true;
            #endif

            if (solidTerrain) {
                UpdateVoxelMap(mat);

                #if WORLD_SPACE_REFLECTIONS_INTERNAL > 0 && !defined SHADOW_COLORWHEEL
                    vec3 normal = mat3(shadowModelViewInverse) * gl_NormalMatrix * gl_Normal;
                    UpdateSceneVoxelMap(mat, normal, position.xyz);
                #endif
            } else if (renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT) {
                UpdateVoxelMap(mat);

                #ifdef PUDDLE_VOXELIZATION
                    UpdatePuddleVoxelMap(mat);
                #endif
            }

            #ifdef COLORED_DYNAMIC_LIGHTING
                else if (currentRenderedItemId >= 10000) {
                    // Thanks to Chistaphee for discovering that we can make dropped items emit colored light via currentRenderedItemId
                    // Then all thanks to SpacEagle17 for making it work without a dynamic light mod

                    int lightId = 0;
                    if (uint(currentRenderedItemId - 44001) < 999u /* same as 44000 < currentRenderedItemId < 45000 */) {
                        lightId = currentRenderedItemId - 44000; // item.properties light IDs
                    } else if (currentRenderedItemId < 40000) {
                        lightId = GetVoxelIDs(currentRenderedItemId); // items which are not in item.properties and come from block.properties (needed for glowing ores)
                    }

                    if (uint(lightId - 2) < 198u /* same as 1 < lightId < 200*/) { // skip none / solid / tint IDs
                        // We skip the item in player's hand as the existing held lighting function looks smoother
                        vec3 eyeRelPos = position.xyz + relativeEyePosition;
                        bool isHeldItem = length(eyeRelPos.xz) < 1.2 && eyeRelPos.y > -1.35 && eyeRelPos.y < 0.5;

                        if (!isHeldItem) {
                            vec3 voxelPos = SceneToVoxel(position.xyz);
                            if (CheckInsideVoxelVolume(voxelPos)) {
                                imageAtomicMax(voxel_img, ivec3(voxelPos), uint(lightId) + ITEM_LIGHT_VOXEL_OFFSET);
                            }
                        }
                    }
                } else if (entityId >= 50000) {
                    int lightId = 0;

                    #include "/lib/materials/materialHandling/shadowEntityLightMaterials.glsl"

                    if (lightId != 0) {
                        vec3 voxelPos = SceneToVoxel(position.xyz);
                        if (CheckInsideVoxelVolume(voxelPos)) {
                            imageAtomicMax(voxel_img, ivec3(voxelPos), uint(lightId) + ENTITY_LIGHT_VOXEL_OFFSET);
                        }
                    }
                }
            #endif
        }

        #if WORLD_SPACE_REFLECTIONS_INTERNAL > 0 && WORLD_SPACE_PLAYER_REF == 1
            UpdatePlayerVertexList(position.xyz);
        #endif
    #endif

    gl_Position = shadowProjection * shadowModelView * position;

    float lVertexPos = sqrt(gl_Position.x * gl_Position.x + gl_Position.y * gl_Position.y);
    float distortFactor = lVertexPos * shadowMapBias + (1.0 - shadowMapBias);
    gl_Position.xy *= 1.0 / distortFactor;
    gl_Position.z = gl_Position.z * 0.2;
}

#endif
